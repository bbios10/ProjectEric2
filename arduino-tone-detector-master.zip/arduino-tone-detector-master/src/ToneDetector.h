/*
 * ToneDetector.h
 *
 *  @date 16.04.2014
 *  @author Armin Joachimsmeyer
 *  Email: armin.joachimsmeyer@gmail.com
 *  License: GPL v3 (http://www.gnu.org/licenses/gpl.html)
 *  Sources: https://github.com/ArminJo/arduino-tone-detector
 */

#ifndef TONEDETECTOR_H_
#define TONEDETECTOR_H_

/*
 * Global settings which are needed at compile time
 */
/*
 * Number of samples used for detecting the frequency of the signal.
 * 1024 -> 53.248 milliseconds / 18.78 Hz at 16 MHz clock with prescaler 64 and 13 cycles/sample (=> 52usec/sample | 19230 Hz sample rate)
 *  512 -> 26.624 milliseconds / 37.56 Hz at  1 MHz clock with prescaler  4 and 13 cycles/sample (=> 52usec/sample | 19230 Hz sample rate)
 */
#if defined (__AVR_ATmega328P__) || defined (__AVR_ATmega328__)
#define NUMBER_OF_SAMPLES 1024
#endif
#if defined(__AVR_ATtiny85__)
#define NUMBER_OF_SAMPLES 512
#endif

/*
 * Defaults for reading
 */
#define ADC_CHANNEL_DEFAULT 1 // Channel ADC1 (PB2 on ATtiny85)
#define RAW_VOLTAGE_MIN_DELTA_DEFAULT 0x40 // 1/16 of max amplitude

/*
 * Defaults for plausibility
 */
#define MIN_SAMPLES_PER_PERIOD 8   // => 2403 Hz at 52usec/sample
// Fixed values for plausibility
#define LEADING_TRAILING_TRIGGER_MARGIN (NUMBER_OF_SAMPLES / 8) // Margin for doPlausi() where at least one trigger (eg. TriggerFirstPosition) must be detected
#define SIZE_OF_PERIOD_LENGTH_ARRAY_FOR_PLAUSI (NUMBER_OF_SAMPLES / MIN_SAMPLES_PER_PERIOD)

/*
 * Defaults for match
 */
#define FREQUENCY_MIN_DEFAULT 1000
#define FREQUENCY_MAX_DEFAULT 2000

#if NUMBER_OF_SAMPLES == 512
#define MAX_DROPOUT_COUNT_BEFORE_NO_FILTERED_MATCH_DEFAULT 6   // => 160 milliseconds for 512 samples at 52usec/sample
#define MIN_NO_DROPOUT_COUNT_BEFORE_ANY_MATCH_DEFAULT 3        // =>  80 milliseconds for 512 samples at 52usec/sample
#else
#define MAX_DROPOUT_COUNT_BEFORE_NO_FILTERED_MATCH_DEFAULT 3   // => 160 milliseconds for 512 samples at 52usec/sample
#define MIN_NO_DROPOUT_COUNT_BEFORE_ANY_MATCH_DEFAULT 2        // => 120 milliseconds for 512 samples at 52usec/sample
#endif

// sample time values for Prescaler for 16 MHz 4(13*0,25=3,25us),8(6,5us),16(13us),32(26us),64(52us),128(104us)
#define PRESCALE4    2
#define PRESCALE8    3
#define PRESCALE16   4
#define PRESCALE32   5
#define PRESCALE64   6
#define PRESCALE128  7

/*
 * Default timing for reading -> 19,23 kHz sample rate
 * Formula is F_CPU / (PrescaleFactor * 13)
 */
#if F_CPU == 16000000L
#define PRESCALE_VALUE_DEFAULT PRESCALE64 // 52 microseconds per ADC sample at 16 Mhz Clock => 19,23kHz sample rate
#elif F_CPU == 1000000L
#define PRESCALE_VALUE_DEFAULT PRESCALE4 // 52 microseconds per ADC sample at 1 Mhz Clock => 19,23kHz sample rate
#endif

// FrequencyActual error values
#define SIGNAL_NO_TRIGGER 0
#define SIGNAL_STRENGTH_LOW 1
#define SIGNAL_FIRST_LAST_PLAUSI_FAILED 2
#define SIGNAL_DISTRIBUTION_PLAUSI_FAILED 3
#define SIGNAL_MAX_ERROR_CODE 3 // the highest error value

// Result values for ToneMatch*
enum MatchStateEnum {
    TONE_MATCH_INVALID /*Erros has happened*/, TONE_MATCH_LOWER, TONE_MATCH, TONE_MATCH_HIGHER
};

struct ToneDetectorControlStruct {

    /****************************************
     * Values used and set by readSignal()
     */
    uint8_t ADCPrescalerValue;
    uint16_t FrequencyOfOneSample;    // to compute the frequency from the number of samples of one signal wave
    uint16_t PeriodOfOneSampleMicros; // to compute the matches needed from the number of loops
    /*
     * Minimum signal strength value to produce valid output and and do new trigger level computation
     */
    uint16_t RawVoltageMinDelta; // Threshold for minimum delta U (raw ADC value) for valid signal strength. 0x40=312mV at 5V and 68.75mY at 1.1V, 0x20=156/34,37 mVolt
    /*
     * Internal values
     */
    uint16_t TriggerLevelUpper; // values for automatic trigger level adjustment
    uint16_t TriggerLevelLower;

    /*
     * Raw frequency output value
     */
    uint16_t FrequencyActual;   // Frequency in Hz or "error code"  SIGNAL_...
    /*
     * Other values computed by readSignal() to be used by doPlausi()
     */
    uint8_t PeriodCountActual; // Actual count of periods in all samples - !!! cannot be greater than SIZE_OF_PERIOD_LEGTH_ARRAY_FOR_PLAUSI - 1)!!!
    uint8_t PeriodLength[SIZE_OF_PERIOD_LENGTH_ARRAY_FOR_PLAUSI]; // Array of period length of the signal for plausi
    uint16_t TriggerFirstPosition; // position of first detection of a trigger in all samples
    uint16_t TriggerLastPosition;  // position of last detection of a trigger in all samples

    /*************************************************
     * Parameters for computeDirectAndFilteredMatch()
     */
    uint16_t FrequencyMatchLow;   // Thresholds for matching
    uint16_t FrequencyMatchHigh;
    uint16_t FrequencyFiltered;   // internal value - low pass filter value for frequency

    uint8_t MaxMatchDropoutCount; // number of allowed FrequencyActual <= SIGNAL_MAX_ERROR_CODE conditions before match = TONE_MATCH_INVALID
    uint8_t MinMatchNODropoutCount; // number of needed FrequencyActual > SIGNAL_MAX_ERROR_CODE conditions before any valid match - to avoid short flashes at random signal input
    uint8_t MatchDropoutCount;      // actual dropout count

    MatchStateEnum ToneMatchDirect;   // Result of match: TONE_MATCH_INVALID, TONE_MATCH_LOWER, TONE_MATCH, TONE_MATCH_HIGHER
    MatchStateEnum ToneMatchFiltered; // Match state processed by low pass filter
    uint16_t MatchLowPassFiltered;    // internal value - low pass filter value for computing ToneMatchFiltered
};

extern ToneDetectorControlStruct ToneDetectorControl;

void setToneDetectorReadingValues(uint8_t aADCChannel, uint8_t aADCReference, uint8_t aADCPrescalerValue,
        uint16_t aRawVoltageMinDelta);
void setToneDetectorReadingPrescaleValue(uint8_t aADCPrescalerValue);
void setToneDetectorMatchValues(uint16_t aFrequencyMin, uint16_t aFrequencyMax);
void setToneDetectorDropoutValues(uint8_t aMinMatchNODropoutCount, uint8_t aMaxMatchDropoutCount);
void setToneDetectorControlDefaults(void);
uint16_t readSignal();
uint16_t doPlausi();
void computeDirectAndFilteredMatch(uint16_t aFrequency);

#endif /* TONEDETECTOR_H_ */
