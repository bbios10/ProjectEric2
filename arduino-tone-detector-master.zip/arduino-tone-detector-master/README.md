# arduino-tone-detector

#SUMMARY
analyzes a microphone signal and outputs the detected frequency.

readSignal() is the ADC read routine, which reads 1 + 1024/512 samples and computes frequency of signal
doPlausi() checks if the signal is not noisy and valid. It uses the following plausibility rules:
    1. A trigger must be detected in first and last 1/8 of samples
    2. Only 1/8 of the samples are allowed to be greater than 1.5 or less than 0.75 of the average period
computeDirectAndFilteredMatch() wait for n matches within a given frequency range (FrequencyMatchLow - FrequencyMatchHigh)
and also low pass filters the result for smooth transitions between the 3 match states (lower, match, greater)

#SimpleToneDetector EXAMPLE
This example reads analog signal e.g. from MAX9812 Voice Module at A1 and computes frequency.
If tone is in the range of 1400 to 1700 Hz, the Arduino built in LED will light up.
It prints the detected frequency as well as plausibility errors.
Frequencies above 800Hz are also printed as bar of asterisks.

SimpleToneDetector on breadboard
![SimpleToneDetector on breadboard](https://github.com/ArminJo/arduino-tone-detector/blob/master/media/SimpleToneDetector.jpg)
Youtube Demonstration of SimpleToneDetector
[![Demonstration of SimpleToneDetector](https://img.youtube.com/vi/tsxfSx0iY5s/0.jpg)](https://www.youtube.com/watch?v=tsxfSx0iY5s)
 
#Pfeiffschalter EXAMPLE
The Pfeiffschalter example analyzes a microphone signal and toggles an output pin, if the main frequency is for a specified duration in a specified range. It works as a tone detector for a whistle tone pitch which operates a mains relay. By using different pitches it is possible to control multiple tone relays in a single room. If the pitch is lower than the specified frequency, the feedback LED blinks slowly, if the pitch is higher it blinks fast. If the match holds for *MATCH_TO_LONG_MILLIS* / 1.0 seconds after switching output, the output switches again, to go back to the former state. This can be useful if a machine generated tone (e.g. from a vacuum cleaner) matches the range.

## PREDEFINED RANGES
the following pitch ranges are predefined for easy selection:

1.   1750 - 2050 Hz  -> 300 Hz
2.   1500 - 1740 Hz  -> 250 Hz
3.   1300 - 1490 Hz  -> 200 Hz
4.   1150 - 1290 Hz  -> 150 Hz
5.   1000 - 1140 Hz  -> 150 Hz
6.    900 -  990 Hz  -> 100 Hz

7.   1550 - 1900 Hz  -> 350 Hz
8.   1250 - 1540 Hz  -> 300 Hz
9.   1000 - 1240 Hz  -> 250 Hz

##SELECTING the RANGE
Selecting is started by a long press of the button.
After BUTTON_PUSH_ENTER_PROGRAM_SIMPLE_MILLIS / 1.5 seconds, the feedback LED blinks once for signaling simple selecting mode.
After BUTTON_PUSH_ENTER_PROGRAM_ADVANCED_MILLIS / 4 seconds, the feedback LED blinks twice for signaling advanced selecting mode.
After releasing the button the selecting mode is entered.

###SIMPLE SELECTING
Press the button once for range 1, twice for range 2 etc. Each button press is echoed by the feedback LED.
Waiting for PROGRAM_MODE_SIMPLE_END_DETECT_MILLIS / 1.5 seconds ends the selecting mode
and the feedback LED echoes the number of button presses recognized.
The needed duration of tone match to toggle the relay is fixed at MATCH_MILLIS_NEEDED_DEFAULT / 1.2 seconds

###ADVANCED SELECTING
Whistle the tone you want to detect, then press the button again.
While you press the button the tone pitch range is measured. i.e. the minimum and maximum frequency of the tone you are whistling is stored.

If you press the button again before the PROGRAM_MODE_ADVANCED_END_DETECT_MILLIS / 3 sec timeout
the duration of this second press is taken as the needed duration for the tone match to toggle the relay.
Otherwise the  MATCH_MILLIS_NEEDED_DEFAULT / 1.2 seconds are taken.
After timeout of PROGRAM_MODE_TIMEOUT_MILLIS / 5 seconds the advanced selecting mode is ended
and the effective duration is echoed by the feedback LED.

##INFO / RESET
After power up or reset, the feedback LED echoes the range number. Range number 10 indicates an individual range, programmed by advanced selecting.
A reset can be performed by power off/on or by pressing the button two times each time shorter than RESET_ENTER_BUTTON_PUSH_MILLIS / 0.12 seconds
within a RESET_WAIT_TIMEOUT_MILLIS / 0.3 second interval.

#SCHEMATIC for external components of ToneDetector / Pfeiffschalter
```
         + 5V                             _____                   o--O PIN REF
         |                             o-|_____|--o               |
         _                             |   1M     |               _
        | |                            |          |              | |
        | | 2k2                        |___|\     |              | | 1M
        |_|                            |  2| \____|              |_|
         |    ____             ____    |   | /6   |   ____   | |  |
         o---|____|-----o-----|____|---o---|/     o--|____|--| |--o--O PIN A1
         |     2k2      |      10k     |  3             10k  | |  |
        ---            |O MICROPHONE   _    LM308        10-100nF _
        --- 1 uF        |             | |                        | |
         |              |             | | 10k                    | | 1M
        ___            ___            |_|                        |_|
                                       |                          |
                                       |                          |
                                      ---                        ___
                                      ---  100 nF
                                       |
                                      ___


         + 5V               o--O PIN REF
         |                  |
         |                  _
         |                 | |
     MAX9812 MICROPHONE    | | 1M
     AMPLIFIER / MODULE    |_|
         |     ____         |
        |O ---|____|--------o--O PIN A1
         |     10k          |
         |                  _
         |                 | |
         |                 | | 1M
        ___                |_|
                            |
                            |
                           ___
```
